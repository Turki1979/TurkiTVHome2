package com.turki.tvhome;

/** الإعدادات اللي ممكن تغيّرها بسهولة من GitHub */
public final class Config {
    private Config() {}

    /** قناة النداء في تطبيق ntfy: لا تعطيها لأحد */
    public static final String NTFY_TOPIC = "turki-tv-a4i4zcw2clqgh8";

    /** الرمز السري: لازم تبدأ رسالتك فيه، مثلاً: 8874 أنا جاي */
    public static final String PIN = "8874";

    /** الاسم اللي يطلع في النداء */
    public static final String SENDER_NAME = "بابا";
    public static final String SENDER_LETTER = "ت";

    /** جدة */
    public static final String CITY = "Jeddah";
    public static final String CITY_AR = "جدة";
    public static final double LAT = 21.5433;
    public static final double LON = 39.1728;
    /** 4 = تقويم أم القرى */
    public static final int PRAYER_METHOD = 4;
}
