package com.turki.tvhome;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** كل التطبيقات المثبتة */
public class AllAppsActivity extends Activity {

    private List<Apps.App> apps;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        apps = Apps.list(this);

        GridView grid = new GridView(this);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        grid.setBackgroundResource(R.drawable.apps_bg);
        grid.setNumColumns(6);
        grid.setPadding(dp(48), dp(40), dp(48), dp(40));
        grid.setClipToPadding(false);
        grid.setHorizontalSpacing(dp(20));
        grid.setVerticalSpacing(dp(24));
        grid.setSelector(android.R.color.transparent);
        grid.setDrawSelectorOnTop(false);
        grid.setAdapter(new Adapter());
        grid.setOnItemClickListener((p, v, pos, id) -> Apps.launch(this, apps.get(pos).pkg));
        grid.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            View last;
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (last != null) highlight(last, false);
                if (v != null) highlight(v, true);
                last = v;
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) {
                if (last != null) highlight(last, false);
                last = null;
            }
        });
        setContentView(grid);
    }

    private void highlight(View cell, boolean on) {
        View tile = ((ViewGroup) cell).getChildAt(0);
        tile.setBackgroundResource(on ? R.drawable.tile_focused : R.drawable.tile_normal);
        float s = on ? 1.08f : 1f;
        cell.animate().scaleX(s).scaleY(s).setDuration(120).start();
    }

    private class Adapter extends BaseAdapter {
        @Override public int getCount() { return apps.size(); }
        @Override public Object getItem(int i) { return apps.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout cell;
            if (convert instanceof LinearLayout) {
                cell = (LinearLayout) convert;
                highlight(cell, false);
            } else {
                cell = new LinearLayout(AllAppsActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)));

                ImageView img = new ImageView(AllAppsActivity.this);
                img.setBackgroundResource(R.drawable.tile_normal);
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                cell.addView(img, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

                TextView t = new TextView(AllAppsActivity.this);
                t.setTextColor(0xFFC9CED8);
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                t.setGravity(Gravity.CENTER);
                t.setSingleLine(true);
                t.setPadding(0, dp(4), 0, 0);
                cell.addView(t);
            }
            Apps.App a = apps.get(pos);
            ImageView img = (ImageView) cell.getChildAt(0);
            TextView t = (TextView) cell.getChildAt(1);
            Drawable banner = Apps.banner(AllAppsActivity.this, a.pkg);
            if (banner != null) { img.setPadding(dp(4), dp(4), dp(4), dp(4)); img.setImageDrawable(banner); }
            else { img.setPadding(dp(22), dp(22), dp(22), dp(22)); img.setImageDrawable(Apps.icon(AllAppsActivity.this, a.pkg)); }
            t.setText(a.label);
            t.setTextColor(Color.rgb(0xC9, 0xCE, 0xD8));
            return cell;
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
