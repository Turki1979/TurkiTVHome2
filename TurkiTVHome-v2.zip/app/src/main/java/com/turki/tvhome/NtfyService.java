package com.turki.tvhome;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** يستمع لقناة ntfy ويطلع النداء على التلفزيون */
public class NtfyService extends Service {

    private static final String CHANNEL = "ntfy_listen";
    private static final int NOTIF_ID = 7;
    private volatile boolean running = false;
    private Thread worker;

    @Override
    public void onCreate() {
        super.onCreate();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) {
            running = true;
            worker = new Thread(this::loop, "ntfy");
            worker.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (worker != null) worker.interrupt();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel ch = new NotificationChannel(CHANNEL, "استقبال النداء", NotificationManager.IMPORTANCE_MIN);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        return b.setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle("شاشة تركي")
                .setContentText("جاهز لاستقبال النداء")
                .setOngoing(true)
                .build();
    }

    private void loop() {
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        long backoff = 2000;
        while (running) {
            HttpURLConnection c = null;
            try {
                String since = prefs.getString("ntfy_last_id", null);
                String url = "https://ntfy.sh/" + Config.NTFY_TOPIC + "/json"
                        + (since != null ? "?since=" + since : "");
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(120000); // ntfy يرسل keepalive كل ٤٥ ثانية تقريباً
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                backoff = 2000;
                String line;
                while (running && (line = r.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    handle(prefs, new JSONObject(line));
                }
            } catch (Exception e) {
                // انقطع الاتصال: نعيد المحاولة
            } finally {
                if (c != null) c.disconnect();
            }
            try { Thread.sleep(backoff); } catch (InterruptedException ie) { return; }
            backoff = Math.min(backoff * 2, 60000);
        }
    }

    private void handle(SharedPreferences prefs, JSONObject o) {
        if (!"message".equals(o.optString("event"))) return;
        String id = o.optString("id", null);
        if (id != null) prefs.edit().putString("ntfy_last_id", id).apply();

        long time = o.optLong("time", 0) * 1000L;
        if (time > 0 && System.currentTimeMillis() - time > 15 * 60 * 1000L) return; // رسالة قديمة

        String title = o.optString("title", "").trim();
        String msg = o.optString("message", "").trim();
        boolean ok = false;
        if (title.equals(Config.PIN)) ok = true;
        if (msg.startsWith(Config.PIN)) { ok = true; msg = msg.substring(Config.PIN.length()).trim(); }
        if (!ok) return; // بدون الرمز السري: نتجاهلها

        String audio = null;
        JSONObject att = o.optJSONObject("attachment");
        if (att != null) {
            audio = att.optString("url", null);
            String name = att.optString("name", "");
            if (msg.startsWith("You received a file")) msg = "";
            if (msg.equals(name)) msg = "";
        }
        if (msg.isEmpty()) msg = audio != null ? "عندك رسالة صوتية" : "نداء";

        CallActivity.savePending(this, msg, audio);
        Intent i = new Intent(this, CallActivity.class)
                .putExtra(CallActivity.EXTRA_MSG, msg)
                .putExtra(CallActivity.EXTRA_AUDIO, audio)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { startActivity(i); } catch (Exception ignored) { }
    }
}
