package com.turki.tvhome;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Build;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** قائمة التطبيقات المثبتة وتشغيلها */
public final class Apps {
    private Apps() {}

    public static final class App {
        public final String pkg;
        public final String label;
        App(String pkg, String label) { this.pkg = pkg; this.label = label; }
    }

    public static List<App> list(Context c) {
        PackageManager pm = c.getPackageManager();
        Map<String, App> map = new LinkedHashMap<>();
        if (Build.VERSION.SDK_INT >= 21) addAll(c, pm, map, Intent.CATEGORY_LEANBACK_LAUNCHER);
        addAll(c, pm, map, Intent.CATEGORY_LAUNCHER);
        List<App> out = new ArrayList<>(map.values());
        final Collator col = Collator.getInstance(new Locale("ar"));
        Collections.sort(out, new Comparator<App>() {
            @Override public int compare(App a, App b) { return col.compare(a.label, b.label); }
        });
        return out;
    }

    private static void addAll(Context c, PackageManager pm, Map<String, App> map, String category) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(category);
        List<ResolveInfo> res;
        try { res = pm.queryIntentActivities(i, 0); } catch (Exception e) { return; }
        for (ResolveInfo r : res) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(c.getPackageName()) || map.containsKey(pkg)) continue;
            map.put(pkg, new App(pkg, String.valueOf(r.loadLabel(pm))));
        }
    }

    public static String label(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) { return null; }
    }

    /** البانر العريض (شكل تلفزيوني) لو موجود */
    public static Drawable banner(Context c, String pkg) {
        if (Build.VERSION.SDK_INT < 20) return null;
        try { return c.getPackageManager().getApplicationBanner(pkg); } catch (Exception e) { return null; }
    }

    public static Drawable icon(Context c, String pkg) {
        try { return c.getPackageManager().getApplicationIcon(pkg); } catch (Exception e) { return null; }
    }

    public static boolean launch(Context c, String pkg) {
        PackageManager pm = c.getPackageManager();
        Intent i = null;
        if (Build.VERSION.SDK_INT >= 21) i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { c.startActivity(i); return true; } catch (Exception e) { return false; }
    }
}
