package com.turki.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static final String PREFS = "turki_tv";
    private static final int SLOTS = 12;          // صفين × 6
    private static final int SLOT_ALL_APPS = 10;  // ثابت: كل التطبيقات
    private static final int SLOT_SETTINGS = 11;  // ثابت: الإعدادات

    private static final String[] PRAYER_KEYS = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
    private static final String[] PRAYER_AR = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private TextView clock, date, prayer;
    private final View[] tiles = new View[SLOTS];
    private String weatherText = "";
    private long lastWeather = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        clock = findViewById(R.id.clock);
        date = findViewById(R.id.date);
        prayer = findViewById(R.id.prayer);

        setupPhotos();
        fillDefaultSlots();
        buildTiles();
        startNtfy();
        askOverlayOnce();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTiles();
        ui.removeCallbacks(tick);
        ui.post(tick);
        refreshData(false);
        CallActivity.showPendingIfAny(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
    }

    /** زر الرجوع في الشاشة الرئيسية ما يسوي شي */
    @Override
    public void onBackPressed() { }

    // ---------------- الصور ----------------

    private void setupPhotos() {
        final LinearLayout box = findViewById(R.id.photos);
        final int[] ids = {R.drawable.photo1, R.drawable.photo2, R.drawable.photo3};
        box.post(new Runnable() {
            @Override public void run() {
                int h = box.getHeight();
                int w = h * 3 / 4;
                box.removeAllViews();
                for (int id : ids) {
                    ImageView iv = new ImageView(MainActivity.this);
                    iv.setImageResource(id);
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    box.addView(iv, new LinearLayout.LayoutParams(w, h));
                }
            }
        });
    }

    // ---------------- التطبيقات ----------------

    private void fillDefaultSlots() {
        if (prefs.getBoolean("slots_init", false)) return;
        List<Apps.App> all = Apps.list(this);
        SharedPreferences.Editor e = prefs.edit();
        int s = 0;
        for (Apps.App a : all) {
            if (s >= SLOT_ALL_APPS) break;
            if (a.pkg.contains("settings")) continue;
            e.putString("slot_" + s, a.pkg);
            s++;
        }
        e.putBoolean("slots_init", true).apply();
    }

    private void buildTiles() {
        LinearLayout r1 = findViewById(R.id.row1);
        LinearLayout r2 = findViewById(R.id.row2);
        for (int i = 0; i < SLOTS; i++) {
            View cell = makeCell(i);
            (i < 6 ? r1 : r2).addView(cell);
        }
        tiles[0].requestFocus();
    }

    private View makeCell(final int slot) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setClipChildren(false);
        cell.setClipToPadding(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(dp(12), dp(6), dp(12), dp(6));
        cell.setLayoutParams(lp);

        FrameLayout tile = new FrameLayout(this);
        tile.setBackgroundResource(R.drawable.tile_bg);
        tile.setFocusable(true);
        tile.setFocusableInTouchMode(true);
        tile.setClickable(true);
        tile.setPadding(dp(6), dp(6), dp(6), dp(6));
        cell.addView(tile, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        ImageView img = new ImageView(this);
        img.setTag("img");
        tile.addView(img, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView sym = new TextView(this);
        sym.setTag("sym");
        sym.setTextColor(Color.WHITE);
        sym.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        sym.setGravity(Gravity.CENTER);
        tile.addView(sym, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView label = new TextView(this);
        label.setTag("label");
        label.setTextColor(0xFFC9CED8);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        label.setPadding(0, dp(4), 0, 0);
        cell.addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        tile.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) {
                float s = has ? 1.1f : 1f;
                v.animate().scaleX(s).scaleY(s).setDuration(150).start();
                if (Build.VERSION.SDK_INT >= 21) {
                    v.setElevation(has ? dp(10) : 0);
                    ((View) v.getParent()).setElevation(has ? dp(10) : 0);
                }
            }
        });
        tile.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openSlot(slot); }
        });
        tile.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                if (slot == SLOT_SETTINGS) { requestOverlay(); return true; }
                if (slot == SLOT_ALL_APPS) return false;
                pickApp(slot);
                return true;
            }
        });
        tiles[slot] = tile;
        return cell;
    }

    private void refreshTiles() {
        for (int i = 0; i < SLOTS; i++) {
            View tile = tiles[i];
            if (tile == null) continue;
            ImageView img = tile.findViewWithTag("img");
            TextView sym = tile.findViewWithTag("sym");
            TextView label = ((View) tile.getParent()).findViewWithTag("label");
            img.setImageDrawable(null);
            sym.setText("");
            sym.setTextColor(Color.WHITE);
            if (i == SLOT_ALL_APPS) { sym.setText("▦"); label.setText("كل التطبيقات"); continue; }
            if (i == SLOT_SETTINGS) { sym.setText("⚙"); label.setText("الإعدادات"); continue; }

            String pkg = prefs.getString("slot_" + i, null);
            String name = pkg == null ? null : Apps.label(this, pkg);
            if (name == null) { sym.setText("+"); sym.setTextColor(0x66FFFFFF); label.setText("اضغط مطوّل"); continue; }
            label.setText(name);
            Drawable banner = Apps.banner(this, pkg);
            if (banner != null) {
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                img.setPadding(0, 0, 0, 0);
                img.setImageDrawable(banner);
            } else {
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                img.setPadding(dp(14), dp(14), dp(14), dp(14));
                img.setImageDrawable(Apps.icon(this, pkg));
            }
        }
    }

    private void openSlot(int slot) {
        if (slot == SLOT_ALL_APPS) { startActivity(new Intent(this, AllAppsActivity.class)); return; }
        if (slot == SLOT_SETTINGS) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { }
            return;
        }
        String pkg = prefs.getString("slot_" + slot, null);
        if (pkg == null || !Apps.launch(this, pkg)) pickApp(slot);
    }

    private void pickApp(final int slot) {
        final List<Apps.App> all = Apps.list(this);
        final String[] names = new String[all.size() + 1];
        names[0] = "— إفراغ المكان —";
        for (int i = 0; i < all.size(); i++) names[i + 1] = all.get(i).label;
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("اختر تطبيق لهذا المكان")
                .setItems(names, (d, which) -> {
                    SharedPreferences.Editor e = prefs.edit();
                    if (which == 0) e.remove("slot_" + slot);
                    else e.putString("slot_" + slot, all.get(which - 1).pkg);
                    e.apply();
                    refreshTiles();
                })
                .show();
    }

    // ---------------- الساعة والصلاة والطقس ----------------

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            Date now = new Date();
            clock.setText(new SimpleDateFormat("h:mm", Locale.US).format(now));
            String d = new SimpleDateFormat("EEEE d MMMM", new Locale("ar")).format(now);
            date.setText(d + " · " + Config.CITY_AR + (weatherText.isEmpty() ? "" : " " + weatherText));
            updatePrayer();
            if (System.currentTimeMillis() - lastWeather > 30 * 60 * 1000L) refreshData(true);
            ui.postDelayed(this, 10_000);
        }
    };

    private void updatePrayer() {
        String day = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        String saved = prefs.getString("prayer_json", null);
        if (saved == null) { prayer.setText("مواقيت الصلاة…"); return; }
        try {
            JSONObject t = new JSONObject(saved);
            if (!day.equals(prefs.getString("prayer_day", ""))) refreshPrayerAsync();
            Calendar now = Calendar.getInstance();
            for (int pass = 0; pass < 2; pass++) {
                for (int i = 0; i < PRAYER_KEYS.length; i++) {
                    String hm = t.getString(PRAYER_KEYS[i]).substring(0, 5);
                    Calendar c = Calendar.getInstance();
                    c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hm.substring(0, 2)));
                    c.set(Calendar.MINUTE, Integer.parseInt(hm.substring(3, 5)));
                    c.set(Calendar.SECOND, 0);
                    if (pass == 1) c.add(Calendar.DAY_OF_MONTH, 1);
                    if (c.after(now)) {
                        long mins = (c.getTimeInMillis() - now.getTimeInMillis()) / 60000 + 1;
                        String at = new SimpleDateFormat("h:mm", Locale.US).format(c.getTime());
                        prayer.setText(PRAYER_AR[i] + " " + at + " · باقي " + (mins / 60) + ":" + String.format(Locale.US, "%02d", mins % 60));
                        return;
                    }
                }
            }
        } catch (Exception e) {
            prayer.setText("مواقيت الصلاة…");
        }
    }

    private boolean prayerLoading = false;

    private void refreshPrayerAsync() {
        if (prayerLoading) return;
        prayerLoading = true;
        new Thread(() -> {
            try {
                String day = new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date());
                String body = get("https://api.aladhan.com/v1/timingsByCity/" + day + "?city=" + Config.CITY
                        + "&country=SA&method=" + Config.PRAYER_METHOD);
                JSONObject timings = new JSONObject(body).getJSONObject("data").getJSONObject("timings");
                prefs.edit()
                        .putString("prayer_json", timings.toString())
                        .putString("prayer_day", new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()))
                        .apply();
                ui.post(this::updatePrayer);
            } catch (Exception ignored) {
            } finally {
                prayerLoading = false;
            }
        }).start();
    }

    private void refreshData(boolean weatherOnly) {
        if (!weatherOnly) {
            String day = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            if (!day.equals(prefs.getString("prayer_day", ""))) refreshPrayerAsync();
        }
        lastWeather = System.currentTimeMillis();
        new Thread(() -> {
            try {
                String body = get("https://api.open-meteo.com/v1/forecast?latitude=" + Config.LAT
                        + "&longitude=" + Config.LON + "&current=temperature_2m,weather_code&timezone=Asia%2FRiyadh");
                JSONObject cur = new JSONObject(body).getJSONObject("current");
                int temp = (int) Math.round(cur.getDouble("temperature_2m"));
                String w = weatherSymbol(cur.getInt("weather_code")) + " " + temp + "°";
                ui.post(() -> { weatherText = w; ui.removeCallbacks(tick); ui.post(tick); });
            } catch (Exception e) {
                lastWeather = System.currentTimeMillis() - 25 * 60 * 1000L; // جرّب بعد ٥ دقايق
            }
        }).start();
    }

    private static String weatherSymbol(int code) {
        if (code == 0) return "☀";
        if (code <= 3) return "⛅";
        if (code == 45 || code == 48) return "🌫";
        if (code >= 95) return "⛈";
        if (code >= 51) return "🌧";
        return "☁";
    }

    static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    // ---------------- النداء ----------------

    private void startNtfy() {
        Intent i = new Intent(this, NtfyService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) { }
    }

    private void askOverlayOnce() {
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) return;
        if (prefs.getBoolean("overlay_asked", false)) return;
        prefs.edit().putBoolean("overlay_asked", true).apply();
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("صلاحية النداء")
                .setMessage("عشان يطلع النداء حتى لو كنت داخل يوتيوب أو أي تطبيق، فعّل \"الظهور فوق التطبيقات\" لـ شاشة تركي.\n\nتقدر ترجع لها بعدين بضغطة مطوّلة على زر الإعدادات.")
                .setPositiveButton("افتح الإعداد", (d, w) -> requestOverlay())
                .setNegativeButton("بعدين", null)
                .show();
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT < 23) return;
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "الصلاحية مفعّلة ✓", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "التلفزيون ما يدعم هذي الشاشة. النداء بيطلع لما تكون في الشاشة الرئيسية.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private int dp(int v) {
        DisplayMetrics m = getResources().getDisplayMetrics();
        return Math.round(v * m.density);
    }
}
