package com.turki.tvhome;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** شاشة النداء: تطلع فوق كل شي */
public class CallActivity extends Activity {

    static final String EXTRA_MSG = "msg";
    static final String EXTRA_AUDIO = "audio";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private Ringtone ring;
    private MediaPlayer player;
    private TextView msgView, playBtn;
    private String audioUrl;

    // ---------- رسالة محفوظة لو ما قدر يطلع وقتها ----------

    static void savePending(Context c, String msg, String audio) {
        c.getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putString("pending_msg", msg)
                .putString("pending_audio", audio)
                .putLong("pending_time", System.currentTimeMillis())
                .apply();
    }

    static void clearPending(Context c) {
        c.getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .remove("pending_msg").remove("pending_audio").remove("pending_time").apply();
    }

    static void showPendingIfAny(Activity a) {
        SharedPreferences p = a.getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        String msg = p.getString("pending_msg", null);
        long t = p.getLong("pending_time", 0);
        if (msg == null) return;
        if (System.currentTimeMillis() - t > 6 * 60 * 60 * 1000L) { clearPending(a); return; } // أقدم من ٦ ساعات
        a.startActivity(new Intent(a, CallActivity.class)
                .putExtra(EXTRA_MSG, msg)
                .putExtra(EXTRA_AUDIO, p.getString("pending_audio", null)));
    }

    // ---------- الشاشة ----------

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        setContentView(buildView());
        bind(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        stopAudio();
        bind(intent);
    }

    private void bind(Intent i) {
        String msg = i.getStringExtra(EXTRA_MSG);
        audioUrl = i.getStringExtra(EXTRA_AUDIO);
        msgView.setText("“" + (msg == null ? "نداء" : msg) + "”");
        playBtn.setVisibility(audioUrl != null ? View.VISIBLE : View.GONE);
        playBtn.setText("▶  اسمع الرسالة الصوتية");
        startRing();
        View focus = audioUrl != null ? playBtn : (View) findViewById(android.R.id.button1);
        focus.requestFocus();
    }

    private View buildView() {
        FrameLayout root = new FrameLayout(this);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setBackgroundResource(R.drawable.call_card);
        card.setPadding(dp(48), dp(36), dp(48), dp(36));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(dp(640), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(card, clp);

        TextView avatar = new TextView(this);
        avatar.setBackgroundResource(R.drawable.avatar);
        avatar.setText(Config.SENDER_LETTER);
        avatar.setTextColor(Color.WHITE);
        avatar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        avatar.setGravity(Gravity.CENTER);
        card.addView(avatar, new LinearLayout.LayoutParams(dp(120), dp(120)));

        TextView from = new TextView(this);
        from.setText("نداء من " + Config.SENDER_NAME);
        from.setTextColor(0xFFBFE8D8);
        from.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        from.setPadding(0, dp(12), 0, 0);
        card.addView(from);

        msgView = new TextView(this);
        msgView.setTextColor(Color.WHITE);
        msgView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        msgView.setTypeface(Typeface.DEFAULT_BOLD);
        msgView.setGravity(Gravity.CENTER);
        msgView.setPadding(0, dp(14), 0, dp(24));
        card.addView(msgView);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(btns, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));

        playBtn = button("▶  اسمع الرسالة الصوتية");
        btns.addView(playBtn, weighted(1.6f));
        playBtn.setOnClickListener(v -> toggleAudio());

        TextView done = button("✓  تم");
        done.setId(android.R.id.button1);
        btns.addView(done, weighted(1f));
        done.setOnClickListener(v -> finish());

        return root;
    }

    private TextView button(String text) {
        final TextView t = new TextView(this);
        t.setText(text);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        t.setTextColor(Color.WHITE);
        t.setBackgroundResource(R.drawable.btn_primary);
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnFocusChangeListener((v, has) -> {
            t.setTextColor(has ? 0xFF111111 : Color.WHITE);
            v.animate().scaleX(has ? 1.05f : 1f).scaleY(has ? 1.05f : 1f).setDuration(120).start();
        });
        return t;
    }

    private LinearLayout.LayoutParams weighted(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w);
        lp.setMargins(dp(8), 0, dp(8), 0);
        return lp;
    }

    // ---------- الصوت ----------

    private void startRing() {
        stopRing();
        try {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            ring = RingtoneManager.getRingtone(this, u);
            if (ring != null) ring.play();
        } catch (Exception ignored) { }
        ui.postDelayed(this::stopRing, 15000);
    }

    private void stopRing() {
        ui.removeCallbacksAndMessages(null);
        if (ring != null) { try { ring.stop(); } catch (Exception ignored) { } ring = null; }
    }

    private void toggleAudio() {
        stopRing();
        if (player != null) { stopAudio(); playBtn.setText("▶  اسمع الرسالة الصوتية"); return; }
        if (audioUrl == null) return;
        playBtn.setText("… جاري التحميل");
        try {
            player = new MediaPlayer();
            if (Build.VERSION.SDK_INT >= 21) {
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            }
            player.setDataSource(audioUrl);
            player.setOnPreparedListener(mp -> { mp.start(); playBtn.setText("■  إيقاف"); });
            player.setOnCompletionListener(mp -> { stopAudio(); playBtn.setText("↻  أعد التشغيل"); });
            player.setOnErrorListener((mp, what, extra) -> { stopAudio(); playBtn.setText("تعذّر التشغيل"); return true; });
            player.prepareAsync();
        } catch (Exception e) {
            stopAudio();
            playBtn.setText("تعذّر التشغيل");
        }
    }

    private void stopAudio() {
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
    }

    @Override
    public void finish() {
        clearPending(this);
        super.finish();
    }

    @Override
    protected void onDestroy() {
        stopRing();
        stopAudio();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() { finish(); }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
